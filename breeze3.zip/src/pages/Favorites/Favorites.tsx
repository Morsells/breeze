// src/pages/Favorites/Favorites.tsx
import React from "react";

const Favorites: React.FC = () => (
  <div>
    <h2>Favoriten</h2>
    <p>Hier findest du deine gespeicherten Städte.</p>
  </div>
);

export default Favorites;

// src/pages/WeatherMap/WeatherMap.tsx
import React from "react";

const WeatherMap: React.FC = () => (
  <div>
    <h2>Wetterkarte</h2>
    <p>Die interaktive Wetterkarte kommt bald.</p>
  </div>
);

export default WeatherMap;

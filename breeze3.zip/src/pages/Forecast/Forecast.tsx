// src/pages/Forecast/Forecast.tsx
import React from "react";

const Forecast: React.FC = () => (
  <div>
    <h2>5-Tage-Vorhersage</h2>
    <p>Hier erscheint bald die Wetterprognose.</p>
  </div>
);

export default Forecast;
